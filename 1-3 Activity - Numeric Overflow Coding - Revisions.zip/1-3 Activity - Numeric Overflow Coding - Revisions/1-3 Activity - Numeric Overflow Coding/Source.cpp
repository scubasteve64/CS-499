#include <iostream>
#include <limits>
#include <stdexcept>

// Enhanced function to add numbers with error handling and logging
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;
    try {
        for (unsigned long int i = 0; i < steps; ++i)
        {
            if (result > std::numeric_limits<T>::max() - increment) {
                throw std::overflow_error("Overflow detected during addition");
            }
            result += increment;
        }
    }
    catch (const std::overflow_error& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return -1;
    }
    return result;
}

// Enhanced function to subtract numbers with error handling and logging
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;
    try {
        for (unsigned long int i = 0; i < steps; ++i)
        {
            if (result < std::numeric_limits<T>::min() + decrement) {
                throw std::underflow_error("Underflow detected during subtraction");
            }
            result -= decrement;
        }
    }
    catch (const std::underflow_error& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return -1;
    }
    return result;
}

// Function to test overflow scenarios
template <typename T>
void test_overflow()
{
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test for Type: " << typeid(T).name() << std::endl;
    T result = add_numbers<T>(start, increment, steps);
    std::cout << "Result: " << +result << std::endl;
}

// Function to test underflow scenarios
template <typename T>
void test_underflow()
{
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test for Type: " << typeid(T).name() << std::endl;
    T result = subtract_numbers<T>(start, decrement, steps);
    std::cout << "Result: " << +result << std::endl;
}

// Main function to execute tests
int main()
{
    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;
    test_overflow<int>();
    test_underflow<int>();
    std::cout << "All Tests Complete!" << std::endl;
    return 0;
}
