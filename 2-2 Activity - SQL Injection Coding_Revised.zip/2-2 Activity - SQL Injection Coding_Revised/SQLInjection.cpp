#include <iostream>
#include <vector>
#include <regex>
#include "sqlite3.h"

typedef std::tuple<std::string, std::string, std::string> user_record;

// Callback function to handle query results
static int callback(void* possible_vector, int argc, char** argv, char** azColName) {
    if (possible_vector == NULL) {
        for (int i = 0; i < argc; i++) {
            std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
        }
        std::cout << std::endl;
    } else {
        auto* rows = static_cast<std::vector<user_record>*>(possible_vector);
        rows->push_back(std::make_tuple(argv[0], argv[1], argv[2]));
    }
    return 0;
}

// Initialize database with secure queries
bool initialize_database(sqlite3* db) {
    char* error_message = NULL;
    const char* sql = "CREATE TABLE USERS (ID INTEGER PRIMARY KEY, NAME TEXT NOT NULL, PASSWORD TEXT NOT NULL);";
    
    int result = sqlite3_exec(db, sql, callback, NULL, &error_message);
    if (result != SQLITE_OK) {
        std::cerr << "Database error: " << error_message << std::endl;
        sqlite3_free(error_message);
        return false;
    }
    return true;
}

// Run a secure parameterized query
bool run_query(sqlite3* db, const std::string& name, std::vector<user_record>& records) {
    sqlite3_stmt* stmt;
    const char* sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME = ?";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        std::cerr << "SQL prepare error: " << sqlite3_errmsg(db) << std::endl;
        return false;
    }

    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_STATIC);
    records.clear();

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        records.emplace_back(
            reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2))
        );
    }

    sqlite3_finalize(stmt);
    return true;
}

int main() {
    sqlite3* db;
    if (sqlite3_open(":memory:", &db) != SQLITE_OK) {
        std::cerr << "Failed to open database: " << sqlite3_errmsg(db) << std::endl;
        return -1;
    }

    if (!initialize_database(db)) {
        sqlite3_close(db);
        return -1;
    }

    std::vector<user_record> records;
    if (run_query(db, "Fred", records)) {
        for (const auto& rec : records) {
            std::cout << "User: " << std::get<1>(rec) << " [ID=" << std::get<0>(rec) << " PWD=" << std::get<2>(rec) << "]\n";
        }
    }
    sqlite3_close(db);
    return 0;
}
